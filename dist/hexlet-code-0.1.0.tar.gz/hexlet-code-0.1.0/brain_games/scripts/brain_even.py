# !/usr/bin/env python3
"""Main function of the game."""
#from brain_games.games.brain_even import brain_even
import brain_games.logic

def main():
    """Main game."""
    print(logic.greeting())
    #brain_even()


if __name__ == '__main__':
    main()
